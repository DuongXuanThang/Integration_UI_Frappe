/// <reference types="vite/client" />
/// <reference types="@histoire/plugin-vue/components" />
