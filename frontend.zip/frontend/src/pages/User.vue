<!-- About.vue -->
<template>
    <div>
      <h2>About Page</h2>
      <!-- Add about page content -->
    </div>
  </template>
  
  <script>
  export default {
    // Add component logic here
  };
  </script>
  
  <style scoped>
  /* Add styling for the about page */
  div {
    background-color: #ecf0f1;
    padding: 10px;
    height: 100%;
  }
  </style>
  